from flask import Flask,render_template,request
import pickle
import numpy as np
from scipy.sparse import csr_matrix
from sklearn.metrics.pairwise import cosine_similarity
from collections import Counter

## Importing data for top 50 books
popular = pickle.load(open('popular.pkl','rb'))
image = pickle.load(open('image.pkl','rb'))

# Importing data for Item-Based Recommendation System
pivot_item = pickle.load(open('pivot_item.pkl','rb'))
similarity_item = pickle.load(open('similarity_item.pkl','rb'))

# Importing data for User-Based Recommendation system
pivot_user = pickle.load(open('pivot_user.pkl','rb'))
user_book_map = pickle.load(open('user_book_map_user.pkl','rb'))

# Building Model for User Based System
sparse_matrix = csr_matrix(pivot_user)
similarity_user = cosine_similarity(sparse_matrix)

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html',
                           book_name=list(popular['Title'].values),
                           author=list(popular['Author'].values),
                           image=list(popular['Image'].values),
                           rating=list(popular['Rating'].values)
                           )

@app.route('/Item-Based Recommendation System')
def recommend_ui():
    return render_template('Item-Based Recommendation System.html')

@app.route('/item',methods=['post'])
def item():
    user_data = request.form.get('user_input')
    index = np.where(pivot_item.index == user_data)[0][0]
    similar_items = sorted(list(enumerate(similarity_item[index])), key=lambda x: x[1], reverse=True)[1:6]

    data = []
    for i in similar_items:
        item = []
        temp_df = image[image['Book-Title'] == pivot_item.index[i[0]]]
        item.extend(list(temp_df.drop_duplicates('Book-Title')['Book-Title'].values))
        item.extend(list(temp_df.drop_duplicates('Book-Title')['Book-Author'].values))
        item.extend(list(temp_df.drop_duplicates('Book-Title')['Image-URL-L'].values))
        data.append(item)
        print(data)

    return render_template('Item-Based Recommendation System.html',data=data)

@app.route('/User-Based Recommendation System')
def recommend_user():
    return render_template('User-Based Recommendation System.html')

@app.route('/item_user', methods=['POST'])
def item_user():
    user_data = request.form.get('user_data')
    user_data = int(user_data)

    if user_data not in pivot_user.index:
        return "The entered User-ID is not in the Database"

    index = np.where(pivot_user.index == user_data)[0][0]
    similar_items = sorted(list(enumerate(similarity_user[index])), key=lambda x: x[1], reverse=True)[1:6]
    similar_users = [pivot_user.index[i[0]] for i in similar_items]
    books = []
    for similar_user in similar_users:
        books += user_book_map[similar_user]
    books = Counter(books)
    books = books.most_common(10)
    recommended_books = [book[0] for book in books if pivot_user.loc[user_data, book[0]] == 0]
    output = []
    for i in recommended_books:
        item = []
        temp_df = image[image['Book-Title'] == i]
        item.extend(list(temp_df.drop_duplicates('Book-Title')['Book-Title'].values))
        item.extend(list(temp_df.drop_duplicates('Book-Title')['Book-Author'].values))
        item.extend(list(temp_df.drop_duplicates('Book-Title')['Image-URL-L'].values))
        output.append(item)
    return render_template('User-Based Recommendation System.html', books=output[:3])


if __name__ == '__main__':
    app.run(port=8080)
